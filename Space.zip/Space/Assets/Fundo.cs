﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fundo : MonoBehaviour {

    void Start()
    {
        Principal.Start();
    }

    void Update () {
        //Move o fundo
        transform.Translate(Vector2.down * Principal.velocidade * Time.deltaTime);

        //retornar quando atingir o limite

        if(transform.position.y < Principal.limite)
        {
            transform.position = new Vector2(transform.position.x, Principal.limite * -1);
        }
		
	}
}
