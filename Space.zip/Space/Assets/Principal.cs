﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Principal : MonoBehaviour {

    public static float velocidade;
    public static float limite;

    public static void Start () {
        velocidade = 3.0f;
        limite = -10.0f;
	}
	
}
