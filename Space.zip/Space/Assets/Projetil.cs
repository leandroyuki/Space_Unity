﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projetil : MonoBehaviour {

    public float velocidade;
	void Start () {
        //destroi o projetil apos 2 segundos
        Destroy(gameObject, 3.0f);
	}
	
	// Update is called once per frame
	void Update () {
        //Move o projetil
        transform.Translate(Vector2.up * velocidade * Time.deltaTime);
	}

    private void OnCollisionEnter2D(Collision2D c)
    {
        if(c.gameObject.tag == "Inimigo")
        {
            Destroy(c.gameObject); //Destroy o inimigo que e recebido no argumento
            Destroy(gameObject); // destroy o projetil
        }
    }
}
